# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'OpenGL_2D_ui.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(992, 598)
        self.groupBox_3 = QtWidgets.QGroupBox(Dialog)
        self.groupBox_3.setGeometry(QtCore.QRect(20, 10, 961, 571))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.groupBox_3.setFont(font)
        self.groupBox_3.setCheckable(False)
        self.groupBox_3.setObjectName("groupBox_3")
        self.label_2 = QtWidgets.QLabel(self.groupBox_3)
        self.label_2.setGeometry(QtCore.QRect(640, 470, 111, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.horizontalSlider_rotate = QtWidgets.QSlider(self.groupBox_3)
        self.horizontalSlider_rotate.setGeometry(QtCore.QRect(760, 470, 181, 22))
        self.horizontalSlider_rotate.setMinimum(-100)
        self.horizontalSlider_rotate.setMaximum(100)
        self.horizontalSlider_rotate.setProperty("value", 0)
        self.horizontalSlider_rotate.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider_rotate.setObjectName("horizontalSlider_rotate")
        self.checkBox_showlabels = QtWidgets.QCheckBox(self.groupBox_3)
        self.checkBox_showlabels.setGeometry(QtCore.QRect(130, 470, 121, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.checkBox_showlabels.setFont(font)
        self.checkBox_showlabels.setChecked(True)
        self.checkBox_showlabels.setObjectName("checkBox_showlabels")
        self.horizontalSlider_zoom = QtWidgets.QSlider(self.groupBox_3)
        self.horizontalSlider_zoom.setGeometry(QtCore.QRect(430, 470, 181, 22))
        self.horizontalSlider_zoom.setMaximum(200)
        self.horizontalSlider_zoom.setProperty("value", 100)
        self.horizontalSlider_zoom.setOrientation(QtCore.Qt.Horizontal)
        self.horizontalSlider_zoom.setObjectName("horizontalSlider_zoom")
        self.label_20 = QtWidgets.QLabel(self.groupBox_3)
        self.label_20.setGeometry(QtCore.QRect(380, 470, 41, 20))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.label_20.setFont(font)
        self.label_20.setObjectName("label_20")
        self.pushButton_Exit = QtWidgets.QPushButton(self.groupBox_3)
        self.pushButton_Exit.setGeometry(QtCore.QRect(390, 510, 112, 34))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.pushButton_Exit.setFont(font)
        self.pushButton_Exit.setObjectName("pushButton_Exit")
        self.openGLWidget = QtWidgets.QOpenGLWidget(self.groupBox_3)
        self.openGLWidget.setGeometry(QtCore.QRect(10, 20, 941, 431))
        self.openGLWidget.setObjectName("openGLWidget")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "OpenGL"))
        self.groupBox_3.setTitle(_translate("Dialog", "OpenGL Simple 2D Drawing"))
        self.label_2.setText(_translate("Dialog", "Rotate"))
        self.checkBox_showlabels.setText(_translate("Dialog", "Show Labels"))
        self.label_20.setText(_translate("Dialog", "Zoom"))
        self.pushButton_Exit.setText(_translate("Dialog", "Exit"))

