import numpy as np

import sys
from PyQt5.QtWidgets import QDialog, QApplication
from PyQt5.QtWidgets import QFileDialog,QMessageBox
from PyQt5.QtGui import QCursor
from PyQt5.QtCore import Qt
from PyQt5.QtOpenGL import QGL, QGLFormat, QGLWidget

from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

from OpenGL_2D_ui import Ui_Dialog

class main_window(QDialog):
    def __init__(self):
        super(main_window,self).__init__()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.assign_widgets()

    #info for scaling the graphics
        self.zoom = 0.75
        self.rotate = 0
        self.deform = 0
        self.width = 1.5
        self.height = 2
        self.xcenter = 0.5
        self.ycenter = 0.8
        self.showlabels = True
        self.show()

    def assign_widgets(self):
        self.ui.pushButton_Exit.clicked.connect(self.ExitApp)
        self.ui.horizontalSlider_zoom.valueChanged.connect(self.ZoomSlider)
        self.ui.horizontalSlider_rotate.valueChanged.connect(self.RotateSlider)
        self.ui.checkBox_showlabels.stateChanged.connect(self.Checkboxes)

        # initialize openGL
        self.ui.openGLWidget.initializeGL = self.initGL
        self.ui.openGLWidget.paintGL = self.paintGL


    def ZoomSlider(self):
        self.zoom = float((self.ui.horizontalSlider_zoom.value()) / 200 + 0.25)
        self.ui.openGLWidget.update()

    def RotateSlider(self):
        self.rotate = float((self.ui.horizontalSlider_rotate.value()))
        self.ui.openGLWidget.update()

    def Checkboxes(self):
        if self.ui.checkBox_showlabels.isChecked():
            self.showlabels = True
        else:
            self.showlabels = False
        self.ui.openGLWidget.update()


    def initGL(self):
        glutInit(sys.argv)


    def ExitApp(self):
        app.exit()

    def paintGL(self):
    # this is a fairly generic widow setup code for 2D graphics
    # the specific drawing code should be placed in Renderscene()
    # Renderscene() is called on the last line of this function

        glClearColor(0.65,0.65,0.65,0)  # pick whatever background you like
        glClear(GL_COLOR_BUFFER_BIT )

        if self.width == None: return # nothing to draw yet

        # setup the drawing window size and scaling
        windowWidth = self.ui.openGLWidget.frameSize().width()
        windowHeight = self.ui.openGLWidget.frameSize().height()
        glViewport(1, 1, windowWidth - 1, windowHeight - 1)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        windowShape = windowWidth/windowHeight
        drawingShape = self.width/self.height
        if drawingShape > windowShape:
            newheight= self.height*drawingShape/windowShape
            top = self.ycenter + newheight/2
            bottom = self.ycenter - newheight/2
            right = self.xcenter + self.width/2
            left = self.xcenter - self.width/2
        else:
            newwidth= self.width*windowShape/drawingShape
            top = self.ycenter + self.height/2
            bottom = self.ycenter - self.height/2
            right = self.xcenter + newwidth/2
            left = self.xcenter - newwidth/2
        glOrtho(left, right, bottom, top, -1, 1)

        glTranslatef(self.xcenter, self.ycenter,0)
        glScalef(self.zoom,self.zoom, 1)
        glRotatef(self.rotate, 0, 0,1)
        glTranslatef(-self.xcenter, -self.ycenter,0)
        self.Renderscene()


    def Renderscene(self):

        # Draw the picture
            glColor3f(0,1,0)
            glLineWidth(4)
            glBegin(GL_LINES)  # begin drawing disconnected lines
            glVertex2f(0,0)
            glVertex2f(0,1)
            glVertex2f(0,1)
            glVertex2f(1,1)
            glVertex2f(1,1)
            glVertex2f(1,0)
            glVertex2f(1,0)
            glVertex2f(0,0)
            glVertex2f(0,1)
            glVertex2f(0.5,1.7)
            glVertex2f(0.5,1.7)
            glVertex2f(1,1)
            glEnd()

            if self.showlabels:
                # draw the label on the house
                glColor3f(1, 1, 1)
                self.drawText('House', 0.2, 0.5)

        # end render scene

    def drawText(self, text, x, y):
        glRasterPos2d(x,y)
        for ch in text:
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ord(ch))
    # end


if __name__ == "__main__":
    app = QApplication.instance()
    if not app:
        app = QApplication(sys.argv)
    app.aboutToQuit.connect(app.deleteLater)
    main_win = main_window()
    sys.exit(app.exec_())
    
 





